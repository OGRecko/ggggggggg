import { beforeEach, describe, expect, it } from "vitest";
import { courses, courseById } from "../courses/catalog";
import { checkRequiredPatterns } from "../utils/exerciseCheck";
import { resolveExportTargets } from "../utils/exportTargets";
import { clearProgress, loadProgress, saveProgress } from "../utils/storage";
import { coverageAudit } from "./coverageAudit";

type MemoryStorage = Storage & { reset: () => void };

const memoryStorage = (): MemoryStorage => {
  const values = new Map<string, string>();
  return {
    get length() { return values.size; },
    clear: () => values.clear(),
    getItem: (key) => values.get(key) ?? null,
    key: (index) => [...values.keys()][index] ?? null,
    removeItem: (key) => { values.delete(key); },
    setItem: (key, value) => { values.set(key, String(value)); },
    reset: () => values.clear(),
  } as MemoryStorage;
};

Object.defineProperty(globalThis, "localStorage", { value: memoryStorage(), configurable: true });

describe("CodeForge course integrity", () => {
  it("loads every supported language with 25 real available chapters", () => {
    expect(courses.map((course) => course.id)).toEqual(["python", "java", "javascript", "cpp", "htmlcss"]);
    for (const course of courses) {
      expect(courseById(course.id)).toBe(course);
      expect(course.chapters).toHaveLength(25);
      expect(course.chapters.every((chapter) => chapter.available)).toBe(true);
      expect(course.chapters.every((chapter) => chapter.lessons.length > 0)).toBe(true);
    }
  });

  it("keeps every chapter number unique and sequential", () => {
    for (const course of courses) {
      expect(course.chapters.map((chapter) => chapter.number)).toEqual(Array.from({ length: 25 }, (_, index) => index + 1));
    }
  });

  it("keeps lesson IDs unique and chapter lesson orders sequential", () => {
    const ids = courses.flatMap((course) => course.chapters.flatMap((chapter) => chapter.lessons.map((lesson) => lesson.id)));
    expect(new Set(ids).size).toBe(ids.length);
    for (const course of courses) {
      for (const chapter of course.chapters) {
        expect(chapter.lessons.map((lesson) => lesson.order)).toEqual(chapter.lessons.map((_, index) => index + 1));
      }
    }
  });

  it("keeps every lesson educationally populated", () => {
    for (const course of courses) {
      for (const chapter of course.chapters) {
        for (const lesson of chapter.lessons) {
          expect(lesson.summary.trim().length).toBeGreaterThan(20);
          expect(lesson.explanation.trim().length).toBeGreaterThan(40);
          expect(lesson.learningGoals.length).toBeGreaterThanOrEqual(3);
          expect(lesson.keywordNotes.length).toBeGreaterThanOrEqual(3);
          expect(lesson.examples.length).toBeGreaterThanOrEqual(2);
          expect(lesson.readingCheck).toBeDefined();
          expect(lesson.exercise.prompt.trim()).not.toBe("");
          expect(lesson.exercise.solution.trim()).not.toBe("");
          expect(lesson.exercise.hints.length).toBeGreaterThan(0);
          expect(lesson.recap.length).toBeGreaterThanOrEqual(3);
          for (const example of lesson.examples) {
            expect(example.code.trim()).not.toBe("");
            expect(example.lines.length).toBe(example.code.split("\n").length);
            expect(example.mistakes.length).toBeGreaterThanOrEqual(2);
          }
        }
      }
    }
  });

  it("provides chapter projects, chapter tests, and cumulative checkpoints", () => {
    for (const course of courses) {
      for (const chapter of course.chapters) {
        expect(chapter.project).toBeDefined();
        expect(chapter.project?.brief.trim()).not.toBe("");
        expect(chapter.project?.solution.trim()).not.toBe("");
        expect(chapter.project?.hints.length).toBeGreaterThan(0);
        expect(chapter.test).toHaveLength(3);
        if (chapter.number % 5 === 0) expect(chapter.cumulativeTest?.length).toBeGreaterThan(0);
      }
    }
  });

  it("keeps every multiple-choice answer index valid", () => {
    for (const course of courses) {
      for (const chapter of course.chapters) {
        for (const question of [...(chapter.test ?? []), ...(chapter.cumulativeTest ?? [])]) {
          expect(question.choices.length).toBeGreaterThanOrEqual(2);
          expect(question.correctIndex).toBeGreaterThanOrEqual(0);
          expect(question.correctIndex).toBeLessThan(question.choices.length);
          expect(question.explanation.trim()).not.toBe("");
        }
      }
    }
  });

  it("adds authored deep labs to each non-Python five-chapter milestone", () => {
    for (const language of ["java", "javascript", "cpp", "htmlcss"] as const) {
      const course = courseById(language)!;
      for (const chapterNumber of [5, 10, 15, 20, 25]) {
        const chapter = course.chapters[chapterNumber - 1];
        expect(chapter.lessons).toHaveLength(6);
        expect(chapter.lessons[5].title).toMatch(/^Lab:/);
        expect(chapter.lessons[5].readingCheck).toBeDefined();
      }
    }
  });

  it("checks required and forbidden structures without claiming compilation", () => {
    const checker = { mode: "patterns" as const, requiredPatterns: ["class\\s+Main", "System\\.out\\.println"], forbiddenPatterns: ["System\\.out\\.prinln"] };
    expect(checkRequiredPatterns('class Main { System.out.println("ok"); }', checker)).toEqual({ passed: true, missing: [], forbidden: [] });
    const failure = checkRequiredPatterns('class Main { System.out.prinln("ok"); }', checker);
    expect(failure.passed).toBe(false);
    expect(failure.missing).toContain("System\\.out\\.println");
    expect(failure.forbidden).toContain("System\\.out\\.prinln");
  });

  it("keeps every structural checker regex valid and non-empty", () => {
    for (const course of courses) {
      for (const lesson of course.chapters.flatMap((chapter) => chapter.lessons)) {
        const checker = lesson.exercise.checker;
        if (!checker) continue;
        expect(checker.requiredPatterns.length).toBeGreaterThan(0);
        for (const pattern of [...checker.requiredPatterns, ...(checker.forbiddenPatterns ?? [])]) expect(() => new RegExp(pattern, "is")).not.toThrow();
      }
    }
  });

  it("selects export targets for a course, chapter, and individual lesson", () => {
    const java = courseById("java")!;
    expect(resolveExportTargets(java, "course", 1, "")).toHaveLength(25);
    expect(resolveExportTargets(java, "chapter", 5, "")[0].number).toBe(5);
    const lesson = java.chapters[4].lessons[0];
    const target = resolveExportTargets(java, "lesson", 5, lesson.id);
    expect(target).toHaveLength(1);
    expect(target[0].lessons).toEqual([lesson]);
  });

  it("keeps the coverage audit conservative about static-only runtimes", () => {
    expect(coverageAudit.Java.every((item) => item.status !== "COMPLETE")).toBe(true);
    expect(coverageAudit["C++"].every((item) => item.status !== "COMPLETE")).toBe(true);
    expect(coverageAudit.Java.some((item) => item.execution.includes("does not claim Java execution"))).toBe(true);
    expect(coverageAudit["C++"].some((item) => item.execution.includes("does not claim C++ execution"))).toBe(true);
  });

  describe("browser progress storage", () => {
    beforeEach(() => (globalThis.localStorage as MemoryStorage).reset());

    it("round-trips saved code, completion, and scores", () => {
      const progress = loadProgress();
      const next = { ...progress, code: { "python-1-1": 'print("saved")' }, completedExercises: ["python-1-1"], testScores: { "python-chapter-1-test": 3 } };
      expect(saveProgress(next)).toBe(true);
      expect(loadProgress().code["python-1-1"]).toBe('print("saved")');
      expect(loadProgress().completedExercises).toContain("python-1-1");
      expect(loadProgress().testScores["python-chapter-1-test"]).toBe(3);
    });

    it("clears saved progress safely", () => {
      expect(saveProgress({ ...loadProgress(), completedExercises: ["java-1-1"] })).toBe(true);
      expect(clearProgress()).toBe(true);
      expect(loadProgress().completedExercises).toEqual([]);
    });
  });
});