export type LanguageId = "python" | "java" | "javascript" | "cpp" | "htmlcss";

export type TestCase = {
  input?: string;
  expected: string;
  label: string;
};

export type Example = {
  title: string;
  code: string;
  output: string;
  explanation: string;
  lines: string[];
  mistakes: { mistake: string; error: string; fix: string }[];
};

export type Exercise = {
  prompt: string;
  starterCode: string;
  solution: string;
  solutionExplanation: string;
  testCases: TestCase[];
  hints: string[];
  checker?: {
    mode: "patterns" | "html";
    requiredPatterns: string[];
    forbiddenPatterns?: string[];
    successMessage?: string;
  };
};

export type Lesson = {
  id: string;
  chapter: number;
  order: number;
  title: string;
  minutes: number;
  summary: string;
  learningGoals: string[];
  explanation: string;
  keywordNotes: string[];
  examples: Example[];
  exercise: Exercise;
  recap: string[];
  decisionGuide?: {
    use: string;
    insteadOf: string;
    reason: string;
  }[];
  readingCheck?: {
    prompt: string;
    choices: string[];
    correctIndex: number;
    explanation: string;
  };
};

export type ChapterTest = {
  question: string;
  choices: string[];
  correctIndex: number;
  explanation: string;
};

export type ProjectExercise = Exercise & {
  title: string;
  brief: string;
  scenario?: string;
  requirements?: string[];
  milestones?: string[];
  acceptanceCriteria?: string[];
  extensionTasks?: string[];
  rubric?: string[];
};

export type Chapter = {
  number: number;
  title: string;
  description: string;
  lessons: Lesson[];
  project?: ProjectExercise;
  test?: ChapterTest[];
  cumulativeTest?: ChapterTest[];
  available: boolean;
};

export type Course = {
  id: LanguageId;
  name: string;
  version: string;
  accent: string;
  icon: string;
  description: string;
  chapters: Chapter[];
};

export type StoredProgress = {
  code: Record<string, string>;
  completedLessons: string[];
  completedExercises: string[];
  projectComplete: string[];
  testScores: Record<string, number>;
  settings: {
    theme: "light" | "dark";
    font: "system" | "dyslexia" | "mono";
    textScale: "normal" | "large" | "larger";
    spacing: "normal" | "relaxed";
  };
};