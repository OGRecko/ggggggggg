import type { Exercise } from "../data/types";

export type StructureCheckResult = {
  passed: boolean;
  missing: string[];
  forbidden: string[];
};

// Java, C++, and HTML/CSS exercises use this transparent on-device review.
// It intentionally reports structural evidence only; it never impersonates a compiler.
export function checkRequiredPatterns(code: string, checker: NonNullable<Exercise["checker"]>): StructureCheckResult {
  const missing = checker.requiredPatterns.filter((pattern) => !new RegExp(pattern, "is").test(code));
  const forbidden = (checker.forbiddenPatterns ?? []).filter((pattern) => new RegExp(pattern, "is").test(code));
  return { passed: missing.length === 0 && forbidden.length === 0, missing, forbidden };
}