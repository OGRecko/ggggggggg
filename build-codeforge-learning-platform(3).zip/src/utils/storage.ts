import type { StoredProgress } from "../data/types";

const KEY = "codeforge-progress-v1";

export const defaultProgress: StoredProgress = {
  code: {},
  completedLessons: [],
  completedExercises: [],
  projectComplete: [],
  testScores: {},
  settings: { theme: "light", font: "system", textScale: "normal", spacing: "normal" },
};

export function loadProgress(): StoredProgress {
  try {
    const value = localStorage.getItem(KEY);
    if (!value) return defaultProgress;
    const parsed = JSON.parse(value) as Partial<StoredProgress>;
    return {
      ...defaultProgress,
      ...parsed,
      code: parsed.code ?? {},
      completedLessons: parsed.completedLessons ?? [],
      completedExercises: parsed.completedExercises ?? [],
      projectComplete: parsed.projectComplete ?? [],
      testScores: parsed.testScores ?? {},
      settings: { ...defaultProgress.settings, ...parsed.settings },
    };
  } catch {
    return defaultProgress;
  }
}

export function saveProgress(progress: StoredProgress): boolean {
  try {
    localStorage.setItem(KEY, JSON.stringify(progress));
    return true;
  } catch {
    return false;
  }
}

export function clearProgress(): boolean {
  try {
    localStorage.removeItem(KEY);
    return true;
  } catch {
    return false;
  }
}