import type { Example } from "../data/types";
import { authoredLesson, type LessonOverrideLibrary } from "./chapterPlanHelpers";

const javaMistakes: Example["mistakes"] = [
  { mistake: "Assuming a checked failure will disappear if you ignore it", error: "An exception path remains unhandled or the API contract becomes misleading", fix: "Name the failure boundary explicitly and decide whether this method should catch, translate, or declare it." },
  { mistake: "Sharing mutable state across threads without naming the synchronization rule", error: "Races, stale reads, or misleading 'works on my machine' behavior", fix: "State who owns the mutation and which construct creates the happens-before relationship." },
  { mistake: "Treating the build tool or runtime as magic background detail", error: "Hidden coupling, brittle startup behavior, or misunderstood diagnostics", fix: "Separate the language rule, the runtime rule, and the build-tool responsibility before changing the code." },
];

const example = (title: string, code: string, output: string, explanation: string, lines: string[]): Example => ({
  title,
  code,
  output,
  explanation,
  lines,
  mistakes: javaMistakes,
});

export const javaAuthoredLessons: LessonOverrideLibrary = {
  8: {
    learn: authoredLesson({
      summary: "Handle I/O and parsing failures honestly by distinguishing recoverable business problems from exceptional technical boundaries.",
      learningGoals: [
        "Explain why checked exceptions exist around file and stream APIs",
        "Use try-with-resources as a lifetime boundary for I/O",
        "Choose whether a method should catch, translate, or declare an exception path",
      ],
      explanation: "Files and parsing are boundary work: the outside world can be missing, malformed, or temporarily unavailable. Java makes many of these risks explicit with checked exceptions so callers cannot accidentally pretend the failure path does not exist. try-with-resources is important because the resource lifetime belongs to the block scope instead of to a remembered manual close call. Catching every exception at the lowest level is not always best; often a method should translate a low-level failure into a domain-level result that the caller can actually act on.",
      keywordNotes: [
        "try-with-resources closes an AutoCloseable resource automatically when the block ends.",
        "A checked exception forces the method signature or catch block to acknowledge a failure boundary.",
        "Translating an exception means converting a low-level technical problem into a higher-level domain message or result.",
      ],
      examples: [
        example(
          "Scope owns the reader lifetime",
          'import java.io.StringReader;\npublic class Main {\n    public static void main(String[] args) throws Exception {\n        try (var reader = new StringReader("ready")) {\n            System.out.println((char) reader.read());\n        }\n    }\n}',
          'r',
          "The reader is acquired for one block, used, and then closed automatically when the block exits.",
          [
            "Line 1: StringReader is imported so the example can focus on resource lifetime without depending on an external file system.",
            "Line 2: Main is the entry class for this static Java sketch.",
            "Line 3: main declares throws Exception so the example can keep the spotlight on try-with-resources instead of on additional catch boilerplate.",
            "Line 4: the reader is created inside the try header, which makes this block the owner of its cleanup lifetime.",
            "Line 5: reader.read() pulls one character code from the stream and the cast converts it for visible output.",
            "Line 6: the block ends here; Java now closes reader automatically even though no explicit close call appears in the body.",
            "Line 7: main ends after the resource scope has already performed its cleanup work.",
          ],
        ),
        example(
          "Translate low-level parsing failure into a domain result",
          'public class Main {\n    static String scoreLabel(String text) {\n        try {\n            int score = Integer.parseInt(text);\n            return score >= 7 ? "pass" : "retry";\n        } catch (NumberFormatException error) {\n            return "invalid score";\n        }\n    }\n    public static void main(String[] args) {\n        System.out.println(scoreLabel("oops"));\n    }\n}',
          'invalid score',
          "The method catches one specific technical failure and returns a domain-level label the caller can display or branch on.",
          [
            "Line 1: Main provides both the reusable helper and the simple call site.",
            "Line 2: scoreLabel names a domain decision instead of exposing parsing details directly to every caller.",
            "Line 3: the try block marks the narrow code path that may throw during parsing.",
            "Line 4: parseInt attempts to convert text into an int. This is the actual technical boundary where malformed input can fail.",
            "Line 5: the ternary converts the valid numeric result into one domain label.",
            "Line 6: the catch block handles NumberFormatException only, which keeps unrelated failures visible instead of swallowing everything.",
            "Line 7: the low-level technical failure becomes the domain result invalid score so callers can respond deliberately.",
            "Line 8: the helper ends after both the success and failure paths return.",
            "Line 9: main begins a small demonstration call.",
            "Line 10: the malformed input triggers the catch path and prints invalid score.",
            "Line 11: main ends after observing the translated result.",
          ],
        ),
      ],
      exercise: {
        prompt: "Write a method label(String text) that tries Integer.parseInt(text). Return pass for scores >= 7, retry otherwise, and invalid when parsing fails. Print label(\"oops\").",
        starterCode: "public class Main {\n    // Build one parsing boundary with a translated result\n}\n",
        solution: 'public class Main {\n    static String label(String text) {\n        try {\n            int score = Integer.parseInt(text);\n            return score >= 7 ? "pass" : "retry";\n        } catch (NumberFormatException error) {\n            return "invalid";\n        }\n    }\n    public static void main(String[] args) {\n        System.out.println(label("oops"));\n    }\n}',
        solutionExplanation: "The method keeps the parsing boundary narrow, then translates NumberFormatException into a caller-friendly domain label instead of leaking the raw failure everywhere.",
        testCases: [{ label: "Invalid score", expected: "invalid" }],
        hints: ["Keep Integer.parseInt inside the try block.", "Catch NumberFormatException rather than Exception.", "Return the domain label instead of printing inside the catch block."],
        checker: {
          mode: "patterns",
          requiredPatterns: ["Integer\\.parseInt", "catch\\s*\\(.*NumberFormatException", "return\\s+\"invalid\"", "System\\.out\\.println"],
          successMessage: "The exercise shows a parsing boundary with a translated invalid result.",
        },
      },
      recap: [
        "I/O and parsing are boundary work, so failure paths are part of the design rather than embarrassing exceptions to hide.",
        "try-with-resources ties cleanup to scope so resource lifetime remains reliable.",
        "A method can translate low-level technical failures into domain-level results when that is more useful for its callers.",
      ],
      readingCheck: {
        prompt: "Why does scoreLabel catch NumberFormatException specifically instead of a broad Exception?",
        choices: [
          "Because the method is handling one expected parsing failure without masking unrelated bugs",
          "Because Java forbids catch (Exception)",
          "Because broad catches make parseInt faster",
          "Because checked exceptions cannot be caught",
        ],
        correctIndex: 0,
        explanation: "Specific catches keep the intended recovery path clear and avoid hiding failures that belong elsewhere.",
      },
      decisionGuide: [
        { use: "try-with-resources for owned I/O lifetimes", insteadOf: "remembering scattered close calls", reason: "Scope now owns cleanup, which keeps normal and exceptional exits consistent." },
        { use: "exception translation when callers need a domain result", insteadOf: "leaking a low-level parsing detail into every caller", reason: "The higher-level API can remain focused on business meaning rather than forcing every caller to rebuild the same error interpretation." },
      ],
      quality: { codeReading: true, prediction: true, debugging: true, modification: true, edgeCase: true },
    }),
  },
  16: {
    learn: authoredLesson({
      summary: "Model Java concurrency around shared state, happens-before guarantees, and coordination tools rather than around hope that thread timing will stay lucky.",
      learningGoals: [
        "Explain why shared mutable state needs a synchronization rule",
        "Use synchronized or lock-based coordination as a happens-before boundary",
        "Differentiate atomic update problems from waiting/notification problems",
      ],
      explanation: "Concurrency bugs are about memory visibility and interleaving, not just about starting multiple threads. If two threads read and update the same mutable value with no synchronization rule, the program has a race. synchronized and java.util.concurrent tools matter because they create happens-before relationships: one thread's writes become safely visible to another thread at the correct time. AtomicInteger helps with one atomic counter update, while wait/notify or higher-level queues solve coordination problems where one thread must wait for another state change.",
      keywordNotes: [
        "A race happens when correctness depends on unsynchronized timing between threads.",
        "A happens-before relationship guarantees visibility ordering between one thread's actions and another's observations.",
        "AtomicInteger helps with one atomic variable update, but it does not replace every coordination primitive.",
      ],
      examples: [
        example(
          "synchronized protects one critical section",
          'public class Main {\n    static class Counter {\n        private int value = 0;\n        synchronized void increment() {\n            value += 1;\n        }\n        int current() { return value; }\n    }\n    public static void main(String[] args) {\n        Counter counter = new Counter();\n        counter.increment();\n        System.out.println(counter.current());\n    }\n}',
          '1',
          "The synchronized method makes one critical section explicit and gives readers a visible rule for how updates become ordered.",
          [
            "Line 1: Main contains the small Counter type and the demonstration call site.",
            "Line 2: Counter groups the shared state with the synchronization rule that protects it.",
            "Line 3: value is the mutable state that would race if several threads updated it unsafely.",
            "Line 4: synchronized makes the whole increment method one monitor-protected critical section and establishes the visibility rule for entering and leaving that monitor.",
            "Line 5: the update itself is still ordinary code, but it now runs under the synchronized boundary.",
            "Line 6: current returns the state for this small example. In a larger design, readers would also need a clear visibility rule.",
            "Line 7: the nested type ends after naming both state and policy.",
            "Line 8: main begins the example use case.",
            "Line 9: one Counter instance is created.",
            "Line 10: increment performs one protected mutation.",
            "Line 11: current exposes the updated value, which is printed for visibility in the static example.",
            "Line 12: main ends here.",
          ],
        ),
        example(
          "Atomic update is different from waiting for work",
          'import java.util.concurrent.atomic.AtomicInteger;\npublic class Main {\n    public static void main(String[] args) {\n        AtomicInteger counter = new AtomicInteger(0);\n        System.out.println(counter.incrementAndGet());\n    }\n}',
          '1',
          "AtomicInteger solves one shared numeric update problem, but it is not the same thing as a queue, a lock, or a wake-up mechanism for waiting threads.",
          [
            "Line 1: AtomicInteger is imported because the example focuses on one atomic state update tool from java.util.concurrent.",
            "Line 2: Main provides the demonstration context.",
            "Line 3: main begins one small atomic-update example.",
            "Line 4: counter owns one integer whose read-modify-write operations must stay atomic.",
            "Line 5: incrementAndGet performs the increment as one atomic operation and returns the new value for observation.",
            "Line 6: main ends here. If the problem were waiting for work to arrive, a different coordination primitive would still be needed.",
          ],
        ),
      ],
      exercise: {
        prompt: "Create a Counter class with private int value = 0, synchronized void increment(), and int current(). Call increment once and print current().",
        starterCode: "public class Main {\n    // Build one synchronized counter\n}\n",
        solution: 'public class Main {\n    static class Counter {\n        private int value = 0;\n        synchronized void increment() {\n            value += 1;\n        }\n        int current() {\n            return value;\n        }\n    }\n    public static void main(String[] args) {\n        Counter counter = new Counter();\n        counter.increment();\n        System.out.println(counter.current());\n    }\n}',
        solutionExplanation: "The counter groups shared state and synchronization together. synchronized marks the mutation boundary and makes the coordination rule reviewable in the source.",
        testCases: [{ label: "Synchronized counter", expected: "1" }],
        hints: ["Put synchronized on the increment method signature.", "Keep value private inside the Counter.", "Print counter.current() after one increment call."],
        checker: {
          mode: "patterns",
          requiredPatterns: ["synchronized\\s+void\\s+increment", "value\\s*\\+=\\s*1", "counter\\.current\\(\\)"],
          successMessage: "The exercise shows one synchronized update boundary around shared state.",
        },
      },
      recap: [
        "Concurrency correctness depends on visibility and interleaving rules, not on lucky thread timing.",
        "synchronized creates a happens-before boundary around monitor-protected work.",
        "Atomic updates, waiting, and larger coordination each need the right tool for the actual concurrency problem.",
      ],
      readingCheck: {
        prompt: "Why is AtomicInteger not a complete replacement for every concurrency primitive?",
        choices: [
          "Because one atomic variable update is different from waiting for work or coordinating larger state changes",
          "Because AtomicInteger can only be used in constructors",
          "Because synchronized is illegal with AtomicInteger",
          "Because Java threads cannot read integers",
        ],
        correctIndex: 0,
        explanation: "AtomicInteger solves one class of shared-update problem. Coordination and waiting often need locks, queues, or other concurrency tools.",
      },
      decisionGuide: [
        { use: "one explicit synchronization rule next to the shared state", insteadOf: "scattered unsynchronized reads and writes", reason: "Reviewers can reason about the policy only when the code makes the boundary visible." },
        { use: "AtomicInteger for one atomic numeric update", insteadOf: "treating it as a universal concurrency answer", reason: "Concurrency design includes waiting, coordination, and ownership questions beyond a single increment operation." },
      ],
      quality: { codeReading: true, prediction: true, debugging: true, modification: true, edgeCase: true },
    }),
  },
  17: {
    learn: authoredLesson({
      summary: "Model Java networking as boundary-oriented API design: shape the request, validate the response, and name timeout or parsing failures honestly.",
      learningGoals: [
        "Use URI to model a structured address instead of slicing strings by hand",
        "Explain why networking code needs distinct success, timeout, and parsing branches",
        "Separate response handling from domain interpretation",
      ],
      explanation: "Networking code crosses two boundaries at once: transport and data shape. URI and HttpRequest-style builders matter because they keep address structure explicit. A successful transport response can still fail later if the body is malformed or incomplete for the domain. Likewise, a timeout is not the same problem as a 404 or a parser error. Professional networking code is easier to maintain when those branches are named separately instead of being flattened into one vague failure path.",
      keywordNotes: [
        "URI models a structured address with separate scheme, host, path, and query pieces.",
        "A timeout is a transport problem; a parsing failure is a data-shape problem after bytes were received.",
        "Separating the transport response from the domain object keeps boundary code easier to review and test.",
      ],
      examples: [
        example(
          "Build the address as data, not string fragments",
          'import java.net.URI;\npublic class Main {\n    public static void main(String[] args) {\n        URI uri = URI.create("https://example.test/api/lessons?topic=java");\n        System.out.println(uri.getPath());\n    }\n}',
          '/api/lessons',
          "URI makes the address structure explicit and lets the code ask for the path directly instead of slicing characters by guesswork.",
          [
            "Line 1: URI is imported because the example wants a structured address object, not manual string parsing.",
            "Line 2: Main provides the tiny demonstration context.",
            "Line 3: main begins the address-building example.",
            "Line 4: URI.create parses the full address into structured parts. If the path format changes later, the code can still read the path through the API rather than brittle string indexes.",
            "Line 5: getPath extracts just the path portion for this example, showing how the structured object can answer one focused networking question.",
            "Line 6: main ends here.",
          ],
        ),
        example(
          "Transport success still needs domain validation",
          'record LessonResponse(int status, String body) {}\npublic class Main {\n    static boolean usable(LessonResponse response) {\n        return response.status() == 200 && !response.body().isBlank();\n    }\n    public static void main(String[] args) {\n        System.out.println(usable(new LessonResponse(200, "ready")));\n    }\n}',
          'true',
          "Even a 200 response is only usable if the body satisfies the domain's expectations. Transport success and data validity are related but different checks.",
          [
            "Line 1: the record models a small transport-layer response shape without pretending a live network call happened here.",
            "Line 2: Main contains the domain validation helper and example call.",
            "Line 3: usable names the domain-level acceptance rule for this response.",
            "Line 4: the condition checks both transport status and body content. Removing the body check would allow a technically successful but unusable blank response.",
            "Line 5: the helper ends after naming the boundary rule.",
            "Line 6: main begins the demonstration call.",
            "Line 7: a response-shaped value is validated and the resulting boolean is printed.",
            "Line 8: main ends here.",
          ],
        ),
      ],
      exercise: {
        prompt: "Use URI.create('https://example.test/health') and print uri.getPath().",
        starterCode: "import java.net.URI;\npublic class Main {\n    public static void main(String[] args) {\n        // Build a URI and print its path\n    }\n}\n",
        solution: 'import java.net.URI;\npublic class Main {\n    public static void main(String[] args) {\n        URI uri = URI.create("https://example.test/health");\n        System.out.println(uri.getPath());\n    }\n}\n',
        solutionExplanation: "URI holds the structured address, and getPath asks the object for the path portion directly instead of using string slicing.",
        testCases: [{ label: "URI path", expected: "/health" }],
        hints: ["Create the URI object first.", "Use the URI API rather than substring logic.", "Print the path returned by getPath()."],
        checker: {
          mode: "patterns",
          requiredPatterns: ["URI\\.create", "getPath\\(\\)", "System\\.out\\.println"],
          successMessage: "The exercise uses URI and prints its path through the structured API.",
        },
      },
      recap: [
        "Networking code crosses transport and data-shape boundaries, so those failure paths should stay distinct.",
        "Structured APIs such as URI are safer than manual string slicing for address handling.",
        "This course teaches the request/response shape honestly without claiming a live HTTP client executed here.",
      ],
      readingCheck: {
        prompt: "Why is a blank body still a separate problem even when response.status() is 200?",
        choices: [
          "Because transport success does not guarantee the body is usable for the domain rule",
          "Because 200 always means parse failure",
          "Because URI prevents blank text",
          "Because Java records cannot store blank strings",
        ],
        correctIndex: 0,
        explanation: "A successful transport status only says the request reached one response path. The program still has to check whether the returned data satisfies its own expectations.",
      },
      decisionGuide: [
        { use: "URI and other structured request builders", insteadOf: "hand-slicing address strings", reason: "The API expresses address parts directly and avoids fragile manual parsing." },
        { use: "distinct timeout, status, and parsing branches", insteadOf: "one vague networking failure bucket", reason: "Different failure types need different retries, logs, and user-facing messages." },
      ],
      quality: { codeReading: true, prediction: true, debugging: true, modification: true, edgeCase: true },
    }),
  },
  19: {
    learn: authoredLesson({
      summary: "Connect heap allocation, object churn, and profiling concepts to what the JVM actually manages for a Java application.",
      learningGoals: [
        "Explain the difference between short-lived allocation and long-lived retained state",
        "Recognize why object churn can matter even when Java has garbage collection",
        "Describe honest limits of this course when discussing profiling and JVM internals",
      ],
      explanation: "The JVM manages memory automatically, but automatic management is not free or unlimited. Short-lived objects are often cheap when they truly die quickly, while accidentally retained objects create long-lived pressure that a garbage collector cannot solve by magic. Performance work starts by measuring real allocation and retention patterns with native tools, not by inventing profiler numbers. This chapter should teach the mental model: object lifetime, retention, and data-shape choice all matter before a profiler even opens.",
      keywordNotes: [
        "Allocation churn means creating many temporary objects so quickly that the runtime spends noticeable effort managing them.",
        "Retention is about what objects remain reachable and therefore cannot be reclaimed yet.",
        "A profiler measures a real running program; this browser course can teach the workflow concept without fabricating profiler output.",
      ],
      examples: [
        example(
          "One immutable value object is cheap to reason about",
          'record Lesson(String title, int minutes) {}\npublic class Main {\n    public static void main(String[] args) {\n        Lesson lesson = new Lesson("Java", 20);\n        System.out.println(lesson.title());\n    }\n}',
          'Java',
          "A small immutable record makes the program's state easy to reason about and tends to avoid accidental long-lived mutation bugs.",
          [
            "Line 1: the record declares a small immutable value shape, which is often easier to reason about than a bag of mutable setters for simple data.",
            "Line 2: Main provides the usage example.",
            "Line 3: main begins the small state-modeling example.",
            "Line 4: one Lesson object is allocated and bound to lesson. The runtime manages its memory, but the program still controls whether it becomes long-lived or stays local.",
            "Line 5: reading the title accessor demonstrates value use without adding extra mutable state.",
            "Line 6: main ends, and the example object becomes unreachable after the frame disappears.",
          ],
        ),
        example(
          "Retained collections matter more than one temporary conversion",
          'import java.util.ArrayList;\npublic class Main {\n    public static void main(String[] args) {\n        var cache = new ArrayList<String>();\n        cache.add("lesson-1");\n        cache.add("lesson-2");\n        System.out.println(cache.size());\n    }\n}',
          '2',
          "A retained collection is a deliberate long-lived structure. If the program forgets to remove obsolete entries, the JVM cannot reclaim them because the list still holds references.",
          [
            "Line 1: ArrayList is imported because retained collections are a common source of memory growth in ordinary application code.",
            "Line 2: Main contains the example.",
            "Line 3: main begins the example scope.",
            "Line 4: cache is a long-lived root for whatever strings it keeps. Reachability, not human intention, decides whether the JVM may reclaim those objects.",
            "Line 5: adding lesson-1 makes the string reachable through cache.",
            "Line 6: adding lesson-2 increases the retained collection size further.",
            "Line 7: printing size shows the visible state, but the educational point is that these elements stay alive while cache keeps references to them.",
            "Line 8: main ends and cache itself becomes unreachable in this tiny example.",
          ],
        ),
      ],
      exercise: {
        prompt: "Create an ArrayList<String> named cache, add two lesson ids, and print cache.size().",
        starterCode: "import java.util.ArrayList;\npublic class Main {\n    public static void main(String[] args) {\n        // Model one retained cache\n    }\n}\n",
        solution: 'import java.util.ArrayList;\npublic class Main {\n    public static void main(String[] args) {\n        var cache = new ArrayList<String>();\n        cache.add("lesson-1");\n        cache.add("lesson-2");\n        System.out.println(cache.size());\n    }\n}\n',
        solutionExplanation: "The ArrayList models a retained structure. The size call makes the current reachability set visible without pretending a profiler ran.",
        testCases: [{ label: "Cache size", expected: "2" }],
        hints: ["Import ArrayList.", "Use add twice before printing the size.", "Think of the list as the owner of the retained entries while it stays reachable."],
        checker: {
          mode: "patterns",
          requiredPatterns: ["ArrayList< ?String", "cache\\.add", "cache\\.size\\(\\)"],
          successMessage: "The exercise models a retained collection and prints its size.",
        },
      },
      recap: [
        "Garbage collection manages memory automatically, but the program still controls allocation rate and object retention through its design choices.",
        "Retained references keep objects alive; unreachable objects become reclaimable.",
        "Profilers and JVM diagnostics should be taught honestly as workflows, not fabricated as browser results.",
      ],
      readingCheck: {
        prompt: "Why can an ArrayList become a memory problem even in a garbage-collected language?",
        choices: [
          "Because the list can keep objects reachable long after the program no longer truly needs them",
          "Because ArrayList disables the garbage collector",
          "Because records cannot be collected",
          "Because Java clears only primitive values",
        ],
        correctIndex: 0,
        explanation: "The garbage collector reclaims unreachable objects. A retained collection keeps its contents reachable until the program removes them or the collection itself becomes unreachable.",
      },
      decisionGuide: [
        { use: "simple value objects for coherent state", insteadOf: "unnecessary mutable containers and wrappers", reason: "Smaller, clearer state shapes reduce accidental retention and make profiling results easier to interpret later." },
        { use: "real profiling tools for performance claims", insteadOf: "invented numbers or folklore", reason: "JVM tuning decisions should come from measurement on a native runtime, not from fabricated output." },
      ],
      quality: { codeReading: true, prediction: true, debugging: true, modification: true, edgeCase: true },
    }),
  },
  21: {
    learn: authoredLesson({
      summary: "Understand build tools as the layer that assembles source, dependencies, tasks, and diagnostics into a maintainable Java application workflow.",
      learningGoals: [
        "Explain what belongs in Gradle or Maven versus in Java source code",
        "Recognize how dependencies and tasks shape the project boundary",
        "Describe why warnings, tests, and packaging steps are part of the engineering workflow",
      ],
      explanation: "Java source code expresses application behavior, but the engineering workflow around it decides how that behavior is compiled, tested, packaged, and run in different environments. Build tools such as Gradle and Maven own dependency resolution, compilation tasks, test execution, and artifact packaging. Treating those responsibilities as invisible magic makes larger codebases brittle because no one can tell where configuration, tasks, or dependencies are supposed to change. The build file is the project contract for how source becomes a runnable artifact.",
      keywordNotes: [
        "A build artifact such as a jar or war is produced by the build system, not by a string inside Java source code.",
        "Dependencies belong in the build configuration so version changes stay visible and centralized.",
        "A build task models one workflow step such as compile, test, package, or run.",
      ],
      examples: [
        example(
          "The build file owns dependency declarations",
          'dependencies {\n    implementation("com.fasterxml.jackson.core:jackson-databind:2.18.0")\n    testImplementation("org.junit.jupiter:junit-jupiter:5.11.0")\n}',
          'A build dependency block sketch',
          "The dependency versions live in the build configuration so the project can change or review them without editing unrelated Java logic.",
          [
            "Line 1: the dependencies block belongs to the build tool, not to a Java class. It describes external libraries the project needs.",
            "Line 2: implementation names a runtime and compile-time dependency for ordinary application code.",
            "Line 3: testImplementation scopes the test framework to test code instead of the production runtime surface.",
            "Line 4: the block ends after stating the dependency contract.",
          ],
        ),
        example(
          "The source file should not pretend to be the build script",
          'public class Main {\n    public static void main(String[] args) {\n        String artifact = "codeforge.jar";\n        System.out.println(artifact);\n    }\n}',
          'codeforge.jar',
          "Printing a jar name can illustrate the artifact concept, but the actual packaging rule belongs to the build tool outside this source file.",
          [
            "Line 1: Main is just application source code, not the build system itself.",
            "Line 2: main provides a tiny visible program boundary for this static example.",
            "Line 3: artifact is just a string label here. It does not create, package, or publish anything by itself.",
            "Line 4: printing the label is educationally harmless as long as the explanation stays honest about where the real packaging workflow lives.",
            "Line 5: the example ends without claiming a real build task executed.",
          ],
        ),
      ],
      exercise: {
        prompt: "Print codeforge.jar in Java and include a comment naming one build-system responsibility such as dependencies, tests, or packaging.",
        starterCode: "public class Main {\n    public static void main(String[] args) {\n        // Name one build-tool responsibility honestly\n    }\n}\n",
        solution: 'public class Main {\n    public static void main(String[] args) {\n        // The build tool resolves dependencies and packages the final jar artifact.\n        System.out.println("codeforge.jar");\n    }\n}\n',
        solutionExplanation: "The source file prints the conceptual artifact name, while the comment keeps the workflow boundary honest by naming what the build tool actually does.",
        testCases: [{ label: "Artifact label", expected: "codeforge.jar" }],
        hints: ["Keep the real build responsibility in a comment, not in a fake runtime claim.", "Use System.out.println for the artifact label.", "Mention a real build concern such as dependencies, tests, or packaging."],
        checker: {
          mode: "patterns",
          requiredPatterns: ["codeforge\\.jar", "System\\.out\\.println", "build|dependenc|packag|test"],
          successMessage: "The exercise prints the artifact name and names one build-tool responsibility honestly.",
        },
      },
      recap: [
        "Build tools own dependency resolution, task execution, and packaging outside the Java source code itself.",
        "A build file is part of the engineering contract for how source turns into an artifact.",
        "Warnings, tests, and packaging belong to the workflow layer even when this browser course cannot run the real build locally.",
      ],
      readingCheck: {
        prompt: "Why is it misleading to treat a printed artifact string inside Main as the actual build configuration?",
        choices: [
          "Because the string is only data in the program; the real build workflow lives in Gradle or Maven configuration",
          "Because Java cannot print strings",
          "Because jar files are created by the JVM automatically from any class",
          "Because dependencies belong inside System.out.println",
        ],
        correctIndex: 0,
        explanation: "The artifact label in source can illustrate the idea, but the real build contract still lives in the build tool's tasks and dependency configuration.",
      },
      decisionGuide: [
        { use: "the build file for workflow structure", insteadOf: "hiding dependency and packaging logic in scattered comments or scripts", reason: "The project boundary stays centralized and reviewable." },
        { use: "task and dependency names that match the real workflow", insteadOf: "treating the build as magic background noise", reason: "Teams debug, review, and change builds more safely when the workflow is explicit." },
      ],
      quality: { codeReading: true, prediction: true, debugging: true, modification: true, edgeCase: true },
    }),
  },
};
